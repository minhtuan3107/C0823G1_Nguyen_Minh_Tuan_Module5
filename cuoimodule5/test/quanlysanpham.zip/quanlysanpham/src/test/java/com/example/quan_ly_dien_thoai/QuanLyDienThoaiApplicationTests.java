package com.example.quan_ly_dien_thoai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyDienThoaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
