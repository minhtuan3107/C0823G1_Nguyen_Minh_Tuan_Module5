package com.example.quan_ly_dien_thoai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyDienThoaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyDienThoaiApplication.class, args);
	}

}
