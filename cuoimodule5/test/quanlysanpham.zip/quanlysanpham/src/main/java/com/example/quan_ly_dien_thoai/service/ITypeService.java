package com.example.quan_ly_dien_thoai.service;

import com.example.quan_ly_dien_thoai.model.Product;
import com.example.quan_ly_dien_thoai.model.Type;

public interface ITypeService {
    Iterable<Type> getList();

}
